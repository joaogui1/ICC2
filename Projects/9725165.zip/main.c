#include <math.h>
#include <stdio.h>
#include "stack.h"
#include <string.h>

//Returns whether a char is an opening bracket
int is_open(char c){
  return (c == '(' || c == '[' || c == '{');
}

//Returns whether a char is a closing bracket
int is_close(char c){
  return (c == ')' || c == ']' || c == '}');
}

//Returns whether a pair of chars is an opening bracket and the corresponding closing bracket
int is_pair(char a, char b){
  return ((a == '(' && b == ')') || (a == '[' && b == ']') || (a == '{' && b == '}'));
}

//Returns whether a char is a binary operation
int is_op(char c){
  return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

//Returns whether a char is an unary operation
int is_unary(char c){
  return (c == '!' || c == '@' || c == '#');
}

//Returns the id of the operation
int op_id(char op){
  if(op == '+') return 0;
  if(op == '-') return 1;
  if(op == '*') return 2;
  if(op == '/') return 3;
  return 4;
}

//Preprocesses the string, removing multichar operations
//Power becomes ^, log becomes !, sqrt becomes @ and
//exponential becomes #. Also removes whitespaces
//If there are two consecutive operations it sets error to true
void preprocess(int *error, char *string, int sz){
  int pos = 0;
  char *aux = calloc(sz + 1, sizeof(char));
  for(int i = 0; i < sz; ++i, ++pos){
    if(string[i] == '*'){
      if(i != sz - 1 && string[i + 1] == '*'){
        aux[pos] = '^';
        ++i;
      }
      else  aux[pos] = '*';
    }
    else if(string[i] == 'l'){
      aux[pos] = '!';
      i += 2;
    }
    else if(string[i] == 's'){
      aux[pos] = '@';
      i += 3;
    }
    else if(string[i] == 'e'){
      aux[pos] = '#';
      i += 2;
    }
    else if(string[i] == ' ' || string[i] == '\t')  --pos;
    else
      aux[pos] = string[i];
  }
  strcpy(string, aux);

  pos = strlen(string);
  for(int i = 1; i < pos; ++i){
    if(is_op(string[i]) && (is_op(string[i - 1]) || is_unary(string[i - 1]))){
      // printf("%s\n%d %c %c\n", string, i, string[i - 1], string[i]);
      *error = 1;
      break;
    }
  }

  free(aux);
}

//Matches the brackets so in open[i] is the position of the opening bracket that
//corresponds to the ith char, while close[i] is the position of the closing bracket.
//If the brackets are invalid sets error to true
void process_brackets(int *error, char *string, int sz, int * open, int *close){
  int aux;
  stack *st;
  st = new_stack();
  for(int i = 0; i < sz; ++i){
    if(is_open(string[i]))  push(st, i);
    else if(is_close(string[i])){
      aux = pop(st);
      if(is_pair(string[aux], string[i])){
        open[i] = aux;
        close[aux] = i;
      }
      else{
        annihilate(st);
        *error = 1;
        return;
      }
    }
  }
  if(st_size(st) > 0){
    annihilate(st);
    *error = 1;
    return;
  }
  annihilate(st);
  return;
}

//Solves the processed expression
//If there's an invalid operation, sets error to true
//Returns the value of the expression if no error was found
double solve(int *error, char* string, int *open, int *close, int *priority, int beg, int end){
  double r1 = 0, r2 = 0;
  while(is_open(string[beg]) && close[beg] == end)  ++beg, --end; //removes unnescessary parentheses
  if(is_unary(string[beg]) && close[beg + 1] == end){ //the whole expression in inside an unary expression
    r1 = solve(error, string, open, close, priority, beg + 2, end - 1);
    if(*error) return 0;

    if(string[beg] == '@'){
      if(r1 < 0){
        *error = 1;
        return 0;
      }
      return sqrt(r1);
    }

    if(string[beg] == '#')  return exp(r1);

    if(r1 <= 0){
      *error = 1;
      return 0;
    }
    return log2(r1);
  }

  //searches for the operation with the least priority
  int pos = end + 1, prio = 6;
  for(int i = end; i >= beg; --i){
    if(is_close(string[i])) i = open[i];//ignores operations inside parentheses
    if(is_op(string[i]) && priority[op_id(string[i])] < prio) pos = i, prio = priority[op_id(string[i])];
  }

  //no operation found, it's just a number
  if(pos == end + 1){
    char *tmp = calloc(end - beg + 2, sizeof(char));
    for(int i = beg; string[i] != '\0' && i <= end; ++i) tmp[i - beg] = string[i];
    r1 = atof(tmp);
    free(tmp);
    return r1;
  }

  else{
      r1 = solve(error, string, open, close, priority, beg, pos - 1);
      if(*error) return 0;

      r2 = solve(error, string, open, close, priority, pos + 1, end);
      if(*error) return 0;

      if(string[pos] == '+')  return r1 + r2;
      if(string[pos] == '-')  return r1 - r2;
      if(string[pos] == '*')  return r1 * r2;

      if(string[pos] == '/'){
        if(r2 == 0){
          *error = 1;
          return 0;
        }
        return r1/r2;
      }
      if(string[pos] == '^')  return pow(r1, r2);
  }

  return 0;
}

int main(){
  double res = 0;
  size_t size = 0;
  char op[4], *expression = NULL;
  int sz, priority[5], *close = NULL, *open = NULL, error = 0;
  for(int i = 5; i > 0; --i){
    scanf("%s", op);
    if(op[1] == '*')  op[0] = '^';
    priority[op_id(op[0])] = i;
  }
  getline(&expression, &size, stdin);
  getline(&expression, &size, stdin);
  while(getline(&expression, &size, stdin) != -1){
    error = 0; //sets error to false
    sz = strlen(expression);
    while(expression[sz] != ',' && expression[sz] != ';') --sz;
    expression[sz] = '\0';
    preprocess(&error, expression, sz);

    if(error){
      printf("Expressao incorreta.\n");
      continue;
    }

    sz = strlen(expression);

    open = realloc(open, sz*sizeof(int));
    memset(open, -1, sz*sizeof(int));
    close = realloc(close, sz*sizeof(int));
    memset(close, -1, sz*sizeof(int));


    process_brackets(&error, expression, sz, open, close);
    if(error){
      printf("Expressao incorreta.\n");
      continue;
    }

    res = solve(&error, expression, open, close, priority, 0, sz - 1);
    if(error){
      printf("Expressao incorreta.\n");
      continue;
    }

    printf("%0.2lf\n", res);
  }
  free(open);
  free(close);
  free(expression);
  return 0;
}
