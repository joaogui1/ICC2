#include "stack.h"
#include <stdio.h>

stack *new_stack(){
  stack *ret;
  ret = calloc(1, sizeof(stack));
  ret -> cap = 1024;
  ret -> v = calloc(ret -> cap, sizeof(int));
  return ret;
}

int st_size(stack *st){
  return st -> pos;
}

void empty(stack *st){
  st -> pos = 0;
}

void push(stack *st, int x){
  st -> v[st -> pos] = x;
  ++(st -> pos);
}

int pop(stack *st){
  if(st -> pos == 0)  return -1;
  return st -> v[--(st -> pos)];
}

void annihilate(stack *st){
  free(st -> v);
  free(st);
}
