#include <stdlib.h>

typedef struct {
  int *v;
  int cap, pos;
}stack;

int st_size(stack *st);
void empty(stack *st);
stack *new_stack();
void push(stack *st, int x);
int pop(stack *st);
void annihilate(stack *st);
